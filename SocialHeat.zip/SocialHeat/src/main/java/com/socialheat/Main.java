package com.socialheat;

import com.socialheat.analysis.DataStat;
import com.socialheat.dao.ProjectDao;

/**
 * 项目起始类
 */
public class Main {

	public static void main(String[] args) throws Exception {
//		  System.out.println("统计开始！ 开始时间为：" + TimeUtil.currentTime() + "\n");
		
		DataStat dataStat = new DataStat();
		
		ProjectDao dao = new ProjectDao("dfzx_baidu", false);

		int topNum = 100;
		int span = 1;
		
        dataStat.analysis(dao, topNum, span);
        
//        System.out.println("统计结束！ 结束时间为：" + TimeUtil.currentTime());
	}
}
