package com.socialheat.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by yuanyuan on 2018/4/18.
 */
public class Stopword {
    public static Set<String> getStopWord(){
        Set<String> set=new HashSet<String>();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(Stopword.class.getResourceAsStream("/userLibrary.dic")));
            String temp = null;
            while (( temp = reader.readLine()) != null) {
                temp = temp.trim();
                set.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return set;
    }

}
